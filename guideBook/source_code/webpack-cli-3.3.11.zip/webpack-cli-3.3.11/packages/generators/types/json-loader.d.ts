declare module "*.json" {
	// eslint-disable-next-line
	const value: any;
	export default value;
}
