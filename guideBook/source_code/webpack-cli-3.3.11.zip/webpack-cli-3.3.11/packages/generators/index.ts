import addonGenerator from "./addon-generator";
import initGenerator from "./init-generator";
import loaderGenerator from "./loader-generator";
import pluginGenerator from "./plugin-generator";

export { addonGenerator, initGenerator, loaderGenerator, pluginGenerator };
