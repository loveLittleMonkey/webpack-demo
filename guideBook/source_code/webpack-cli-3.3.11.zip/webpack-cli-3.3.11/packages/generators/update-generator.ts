import * as Generator from "yeoman-generator";

export default class UpdateGenerator extends Generator {}
