export interface Error {
	stack?: string;
	message: string;
}
