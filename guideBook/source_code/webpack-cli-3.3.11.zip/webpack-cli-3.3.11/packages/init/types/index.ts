export interface Error {
	message?: string;
}
