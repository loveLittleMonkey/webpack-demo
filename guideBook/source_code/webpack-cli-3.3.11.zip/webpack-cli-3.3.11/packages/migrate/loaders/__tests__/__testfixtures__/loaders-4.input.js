module.exports = {
  module: {
	postLoaders: [
		{
		loader: "my-post",
		test: /\.js$/,
		},
	],
  },
};
