module.exports = {
  module: {
	preLoaders: [
		{
		loader: "eslint",
		test: /\.js$/,
		},
	],
  },
};
