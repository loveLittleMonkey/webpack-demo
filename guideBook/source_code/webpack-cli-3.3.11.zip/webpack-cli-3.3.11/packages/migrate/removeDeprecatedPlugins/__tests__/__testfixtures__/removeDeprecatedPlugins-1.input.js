module.exports = {
	plugins: [new webpack.optimize.DedupePlugin()]
};
