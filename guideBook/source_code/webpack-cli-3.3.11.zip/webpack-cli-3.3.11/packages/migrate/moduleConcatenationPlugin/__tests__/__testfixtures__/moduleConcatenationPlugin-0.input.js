module.exports = {
	plugins: [new webpack.optimize.ModuleConcatenationPlugin()]
};
