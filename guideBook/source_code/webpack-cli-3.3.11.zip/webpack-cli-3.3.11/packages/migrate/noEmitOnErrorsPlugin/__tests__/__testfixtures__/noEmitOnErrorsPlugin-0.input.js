module.exports = {
	plugins: [new webpack.NoEmitOnErrorsPlugin()]
};
