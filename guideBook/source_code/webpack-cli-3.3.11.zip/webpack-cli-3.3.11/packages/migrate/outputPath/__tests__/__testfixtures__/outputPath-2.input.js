module.exports = {
	output: {
		path: "dist"
	}
};
