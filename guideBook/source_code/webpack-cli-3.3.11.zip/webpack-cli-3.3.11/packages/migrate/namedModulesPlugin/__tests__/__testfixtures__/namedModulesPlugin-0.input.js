module.export = {
    plugins: [
        new webpack.NamedModulesPlugin()
    ]
}
