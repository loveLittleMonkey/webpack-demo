// Do not create LoaderOptionsPlugin is not necessary
module.exports = {
    plugins: [
        new SomePlugin()
    ]
}
