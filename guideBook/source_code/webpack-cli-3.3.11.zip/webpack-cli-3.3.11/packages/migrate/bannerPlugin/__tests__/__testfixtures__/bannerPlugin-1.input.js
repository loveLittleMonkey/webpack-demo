// Should do nothing if there is no banner plugin
module.exports = {
    plugins: []
}
