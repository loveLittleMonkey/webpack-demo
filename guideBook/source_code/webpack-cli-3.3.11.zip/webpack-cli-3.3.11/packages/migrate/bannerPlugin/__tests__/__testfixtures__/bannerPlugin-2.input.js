// Only transform if it uses the old format
module.exports = {
    plugins: [
        new webpack.BannerPlugin({})
    ]
}
