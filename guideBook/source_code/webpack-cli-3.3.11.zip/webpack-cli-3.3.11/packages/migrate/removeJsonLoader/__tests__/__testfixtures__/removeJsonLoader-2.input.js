module.exports = {
	module: {
		rules: [
			{
				loader: "json-loader",
				test: /\.json/
			}
		]
	}
};
