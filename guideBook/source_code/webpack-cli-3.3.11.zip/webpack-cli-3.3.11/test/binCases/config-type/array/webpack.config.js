module.exports = [
	{
		entry: "./entry-a",
		output: {
			filename: "entry-a.bundle.js"
		}
	},
	{
		entry: "./entry-b",
		output: {
			filename: "entry-b.bundle.js"
		}
	}
];
