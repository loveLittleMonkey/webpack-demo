module.exports = "entry-a.js";
