module.exports = "entry-b.js";
