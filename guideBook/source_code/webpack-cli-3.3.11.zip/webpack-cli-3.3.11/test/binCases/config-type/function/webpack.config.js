module.exports = function(env) {
	return {
		entry: "./entry",
		output: {
			filename: "entry.bundle.js"
		}
	};
};
