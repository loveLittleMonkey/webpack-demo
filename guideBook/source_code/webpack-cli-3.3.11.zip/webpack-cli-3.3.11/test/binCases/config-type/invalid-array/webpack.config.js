module.exports = [
	{
		entry: "./entry-a",
		output: {
			filename: "entry-a.bundle.js"
		}
	},
	"this string makes this array of configurations invalid.",
	{
		entry: "./entry-b",
		output: {
			filename: "entry-b.bundle.js"
		}
	}
];
