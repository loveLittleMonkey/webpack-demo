/* eslint-disable no-unused-vars */
const foo = require("./foo");
