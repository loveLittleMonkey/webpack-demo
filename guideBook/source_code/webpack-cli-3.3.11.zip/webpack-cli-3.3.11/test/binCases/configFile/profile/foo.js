require("./bar");

console.log("foo");
