module.exports = {
	entry: "hey"
};
