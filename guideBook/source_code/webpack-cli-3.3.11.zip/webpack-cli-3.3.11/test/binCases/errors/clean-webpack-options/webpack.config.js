module.exports = {
	context: [__dirname],
	entry: "./index"
};
