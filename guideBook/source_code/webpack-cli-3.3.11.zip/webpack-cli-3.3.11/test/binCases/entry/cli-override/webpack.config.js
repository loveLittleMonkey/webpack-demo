const path = require("path");

module.exports = {
	entry: {
		configEntry: path.resolve(__dirname, "./index")
	}
};
