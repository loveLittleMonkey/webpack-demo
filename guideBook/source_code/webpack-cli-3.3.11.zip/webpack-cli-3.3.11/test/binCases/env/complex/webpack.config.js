module.exports = function(env) {
	return {
		stats: {
			env: true
		}
	};
};
