module.exports = [
	{
		name: "bar"
	}
];
