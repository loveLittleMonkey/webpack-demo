module.exports = "webpack-babel-config";
