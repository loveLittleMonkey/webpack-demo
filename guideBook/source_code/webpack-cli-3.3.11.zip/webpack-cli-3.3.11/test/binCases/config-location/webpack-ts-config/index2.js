module.exports = "webpack-ts-config";
