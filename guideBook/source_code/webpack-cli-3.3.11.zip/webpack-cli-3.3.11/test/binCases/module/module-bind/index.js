/* eslint-disable no-unused-vars */
var pre = require("./file.pre");
var post = require("./file.post");
module.exports = "foo";
